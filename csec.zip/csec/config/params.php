<?php

return [
    'adminEmail' => 'support@csec.keshokenya.or.ke',
];
